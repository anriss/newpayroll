package com.cg.payroll.test;
import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayrollDBUtil;


public class PayrollServicesTest {

	public static PayrollServicesImpl services;

	@BeforeClass
	public static void setUpTestEnv(){
		services = new PayrollServicesImpl();
	}

	@Before
	public void setUpTestData()
	{
		Associate associate1 = new Associate(101,"Rishabh","Anand","Student","Intern","desg16g",
				"rishabhanand@gmail.com", new Salary(3500,180, 540, 50, 50,40,10, 50,60, 80), new BankDetails(11234,"citi bank","citi00005"));
		Associate associate2 = new Associate(102,"Rishabh","Anand","Student","Intern","desg16g",
				"rishabhanand@gmail.com", new Salary(3500,180, 540, 50, 50,40,10, 50,60, 80), new BankDetails(11234,"citi bank","citi00005"));

		PayrollDBUtil.associates.put(associate1.getAssociateId(), associate1);
		PayrollDBUtil.associates.put(associate2.getAssociateId(), associate2);
		PayrollDBUtil.ASSOCIATE_ID_COUNTER=102;
	}
	
	@Test(expected = AssociateDetailsNotFoundException.class)
	public void testGetAssociateDetailsForInvalidAssociateId() throws AssociateDetailsNotFoundException{
		services.getAssociateDetails(12321);
	}
	
	@Test
	public void getAssociateDetailsForValidAssociateId()throws AssociateDetailsNotFoundException{
		Associate expectedAssociate= new  Associate(101,"Rishabh","Anand","Student","Intern","desg16g",
				"rishabhanand@gmail.com", new Salary(3500,180, 540, 50, 50,40,10, 50,60, 80), new BankDetails(11234,"citi bank","citi00005"));
		Associate actualAssociate=services.getAssociateDetails(102);
		Assert.assertEquals(expectedAssociate, actualAssociate);

	}
	
	@Test
	public void testGetAllAssociateDetails() {
		Associate associate1 = new Associate(101,"Rishabh","Anand","Student","Intern","desg16g",
				"rishabhanand@gmail.com", new Salary(3500,180, 540, 50, 50,40,10, 50,60, 80), new BankDetails(11234,"citi bank","citi00005"));
		Associate associate2 = new Associate(102,"Rishabh","Anand","Student","Intern","desg16g",
				"rishabhanand@gmail.com", new Salary(3500,180, 540, 50, 50,40,10, 50,60, 80), new BankDetails(11234,"citi bank","citi00005"));
		
		ArrayList<Associate>expectedArrayList= new ArrayList<>();
		expectedArrayList.add(associate1);
		expectedArrayList.add(associate2);
		ArrayList<Associate>actualAssociatesList=(ArrayList<Associate>) services.getAllAssociatesDetails();
		Assert.assertEquals(expectedArrayList, actualAssociatesList);
	}
	
	@After
	public void tearDownTestData() {
		PayrollDBUtil.associates.clear();
		PayrollDBUtil.ASSOCIATE_ID_COUNTER=100;
	}
	
	@Test
	public void testAcceptAssociateDetailsForValidData() {
		int expectedId=103;
		int actualId= services.acceptAssociateDetails("Anirudh", "Bajaj", "anirudhbajaj4@gmail.com", "Student", "Intern", "fe85drg4", 2000, 51351, 56, 40, 166, "CitiBank");
	Assert.assertEquals(expectedId, actualId);
	}
	
	
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testCalculateNetSalaryForInvalidAssociateId() throws AssociateDetailsNotFoundException{
		services.calculateNetSalary(1434);
	}
	
	@Test
	public void testCalculateNetSalaryForValidAssociteId() throws AssociateDetailsNotFoundException{
		Assert.assertEquals(0,services.calculateNetSalary(102));
	}
	@AfterClass
	public static void tearDownTestEnv() {
		services=null;
	}
}
