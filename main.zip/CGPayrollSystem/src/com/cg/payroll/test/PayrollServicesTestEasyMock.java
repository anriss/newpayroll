package com.cg.payroll.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.daoservices.AssociateDAO;
import com.cg.payroll.util.PayrollDBUtil;

public class PayrollServicesTestEasyMock {
	private static PayrollServices payrollServies;
	public static AssociateDAO mockAssociateDAO;

	@BeforeClass
	public static void setUpTestEnv() {
		mockAssociateDAO= EasyMock.mock(AssociateDAO.class);
	}
	public void setUpTestMockData() {
		Associate associate1 = new Associate(101,"Rishabh","Anand","Student","Intern","desg16g",
				"rishabhanand@gmail.com", new Salary(3500,180, 540, 50, 50,40,10, 50,60, 80), new BankDetails(11234,"citi bank","citi00005"));
		Associate associate2 = new Associate(102,"Rishabh","Anand","Student","Intern","desg16g",
				"rishabhanand@gmail.com", new Salary(3500,180, 540, 50, 50,40,10, 50,60, 80), new BankDetails(11234,"citi bank","citi00005"));

		Associate associate3 = new Associate(615, "Anirudh", "Bajaj", "Student", "Intern", "jfai11", "anirudhbajaj4@gmail.com", new Salary(3500,180, 540, 50, 50,40,10, 50,60, 80), new BankDetails(11234,"citi bank","citi00005"));
		/*PayrollDBUtil.associates.put(associate1.getAssociateId(), associate1);
	PayrollDBUtil.associates.put(associate2.getAssociateId(), associate2);
	PayrollDBUtil.ASSOCIATE_ID_COUNTER=102;*/
	
	ArrayList<Associate>associatesList= new ArrayList<Associate>();
	associatesList.add(associate1);
	associatesList.add(associate2);
	EasyMock.expect(mockAssociateDAO.save(associate3)).andReturn(associate3);
	
	EasyMock.expect(mockAssociateDAO.findOne(101)).andReturn(associate1);
	EasyMock.expect(mockAssociateDAO.findOne(102)).andReturn(associate2);
	EasyMock.expect(mockAssociateDAO.findOne(1234)).andReturn(null);
	EasyMock.expect(mockAssociateDAO.findAll()).andReturn(associatesList);
	EasyMock.expect(mockAssociateDAO);
	}
	
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testGetAssociatesDetailsForInvalidAssociate()throws AssociateDetailsNotFoundException{
		payrollServies.getAssociateDetails(1234);
		EasyMock.verify(mockAssociateDAO.findOne(1234));
	}
	
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testGetAssociateDataForValidAssociateId()throws AssociateDetailsNotFoundException{
		Associate expectedAssociate=new Associate(102,"Rishabh","Anand","Student","Intern","desg16g",
				"rishabhanand@gmail.com", new Salary(3500,180, 540, 50, 50,40,10, 50,60, 80), new BankDetails(11234,"citi bank","citi00005"));
		Associate actualAssociate=payrollServies.getAssociateDetails(102);
		assertEquals(expectedAssociate, actualAssociate);
		EasyMock.verify(mockAssociateDAO.findOne(102));
	}
	@After
	public void tearDownTestMockData() {
		EasyMock.resetToDefault(mockAssociateDAO);
	}
	@AfterClass
	public static void tearDownTestEnv() {
		mockAssociateDAO=null;
		payrollServies=null;
	}
}
